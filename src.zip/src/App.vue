<script setup lang="ts"></script>

<template>
  <div class="page">
    <RouterView />
  </div>
</template>

<style scoped></style>
