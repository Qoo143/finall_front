// /api/product.ts
import axios from "axios";

export function getProduct(id: string) {
  return axios.get(`/api/products/${id}`);
}

export function createProduct(data: FormData) {
  return axios.post("/api/products", data);
}

export function updateProduct(id: string, data: FormData) {
  return axios.put(`/api/products/${id}`, data);
}
