<template>
  <div>分類管理</div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss"></style>
